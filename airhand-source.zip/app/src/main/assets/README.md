Place TFLite models here for runtime inference.

Required:
- hand_landmark.tflite  (MediaPipe hand landmark model)

Optional:
- palm_detection.tflite

These are not included due to licensing and binary size. Download or generate from the MediaPipe project and copy them into this folder.
